<?php namespace ProcessWire;

/**
 * This _init.php file is called automatically by ProcessWire before every page render
 * 
 */

/** @var ProcessWire $wire */

include_once('./_uikit.php'); 

