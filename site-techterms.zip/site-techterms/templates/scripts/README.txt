We typically use this directory for javascript files, 
but this site profile does not have any at present.
This file is a placeholder so that this directory
exists in Git. 
