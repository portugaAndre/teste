This directory is for site-specific plugin modules. 
Please see the URL below for more information:

https://processwire.com/docs/modules/about-site-modules/

